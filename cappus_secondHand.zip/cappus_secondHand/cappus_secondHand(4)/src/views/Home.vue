<template>
  <div class="home-container">
    <el-row :gutter="20">
      <el-col :span="24">
        <el-carousel height="400px" class="banner">
          <el-carousel-item v-for="item in bannerItems" :key="item.id">
            <div class="banner-content" :style="{ backgroundImage: `url(${item.image})` }">
              <h2>{{ item.title }}</h2>
              <p>{{ item.description }}</p>
            </div>
          </el-carousel-item>
        </el-carousel>
      </el-col>
    </el-row>

    <el-row :gutter="20" class="category-section">
      <el-col :span="24">
        <h2 class="section-title">商品分类</h2>
      </el-col>
      <el-col :span="4" v-for="category in productStore.categories" :key="category.id">
        <el-card class="category-card" shadow="hover" @click="handleCategoryClick(category)">
          <div class="category-name">{{ category.name }}</div>
        </el-card>
      </el-col>
    </el-row>

    <el-row :gutter="20" class="latest-products">
      <el-col :span="24">
        <h2 class="section-title">最新上架</h2>
      </el-col>
      <el-col :span="6" v-for="product in latestProducts" :key="product.id">
        <el-card class="product-card" shadow="hover" @click="viewProduct(product.id)">
          <img :src="product.image" class="product-image">
          <div class="product-info">
            <h3>{{ product.title }}</h3>
            <p class="price">¥{{ product.price }}</p>
            <p class="description">{{ product.description }}</p>
          </div>
        </el-card>
      </el-col>
    </el-row>
  </div>
</template>

<script setup>
import { ref } from 'vue'
import { useRouter } from 'vue-router'
import { useProductStore } from '../stores'

const router = useRouter()
const productStore = useProductStore()

const bannerItems = ref([
  {
    id: 1,
    title: '校园二手交易平台',
    description: '让闲置物品流转起来',
    image: 'https://example.com/banner1.jpg'
  },
  {
    id: 2,
    title: '安全可靠的交易环境',
    description: '校园认证，安全保障',
    image: 'https://example.com/banner2.jpg'
  }
])

const latestProducts = ref([
  {
    id: 1,
    title: '全新iPad Pro',
    price: 3999,
    description: '95新，去年购入，现在不怎么用了',
    image: 'https://example.com/ipad.jpg'
  },
  // 更多商品数据...
])

const handleCategoryClick = (category) => {
  router.push({
    path: '/products',
    query: { category: category.id }
  })
}

const viewProduct = (productId) => {
  router.push(`/product/${productId}`)
}
</script>

<style scoped>
.home-container {
  padding: 20px;
}

.banner {
  margin-bottom: 40px;
  border-radius: 8px;
  overflow: hidden;
}

.banner-content {
  height: 100%;
  background-size: cover;
  background-position: center;
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
  color: white;
  text-align: center;
  background-color: rgba(0, 0, 0, 0.4);
}

.section-title {
  margin-bottom: 20px;
  font-size: 24px;
  color: #303133;
}

.category-section {
  margin-bottom: 40px;
}

.category-card {
  height: 100px;
  display: flex;
  align-items: center;
  justify-content: center;
  cursor: pointer;
  transition: transform 0.3s;
}

.category-card:hover {
  transform: translateY(-5px);
}

.category-name {
  font-size: 16px;
  color: #606266;
}

.product-card {
  margin-bottom: 20px;
  cursor: pointer;
  transition: transform 0.3s;
}

.product-card:hover {
  transform: translateY(-5px);
}

.product-image {
  width: 100%;
  height: 200px;
  object-fit: cover;
}

.product-info {
  padding: 14px;
}

.product-info h3 {
  margin: 0 0 10px;
  font-size: 16px;
  color: #303133;
}

.price {
  color: #f56c6c;
  font-size: 20px;
  font-weight: bold;
  margin: 5px 0;
}

.description {
  color: #909399;
  font-size: 14px;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}
</style>